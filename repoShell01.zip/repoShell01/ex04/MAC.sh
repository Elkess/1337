#!/bin/sh
ifconfig | grep -w "ether" | cut -f 2 -d " "
